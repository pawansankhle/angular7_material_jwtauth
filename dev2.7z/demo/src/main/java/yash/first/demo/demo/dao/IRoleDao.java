package yash.first.demo.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import yash.first.demo.demo.model.Role;

@Repository
public interface IRoleDao extends JpaRepository<Role,Long>{
	Role findByRole(String role);
}
