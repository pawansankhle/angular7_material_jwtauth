package yash.first.demo.demo.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetailsService;

import yash.first.demo.demo.model.User;


public interface IUserService {
	
	User findByEmail(String email);
	ResponseEntity save(User user);
    List<User> findAll();
    void delete(long id);
   
    User findOne(String username);

    User findById(Long id);
}
