package yash.first.demo.demo.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import yash.first.demo.demo.model.User;
import yash.first.demo.demo.service.IUserService;
import yash.first.demo.demo.util.Util;
import yash.first.demo.demo.util.UtilMessages;



@Controller
@RequestMapping(value = "/user")
public class UserController {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	 
	
	@Autowired
	IUserService userService;
	
	@GetMapping(value={"/findAll"})
	public ResponseEntity<List<User>>  findAll() {
		LOGGER.info("inside @class UserController @method findAll entry..");
		return new ResponseEntity<List<User>>(userService.findAll(), HttpStatus.OK);
		
	}
	
	
	@PostMapping("/signup")
    public ResponseEntity createNewUser(@RequestBody User user, BindingResult bindingResult) {
		LOGGER.info("inside @class UserController @method signup entry..");
		User userExists = userService.findByEmail(user.getEmail());
        if (userExists != null) {
            return Util.getMessage(UtilMessages.USER_EXIST, false);
            
        }
        if (bindingResult.hasErrors()) {
        	return Util.getMessage(UtilMessages.USER_CREATION_ERROR, false);
            
        } else {
            userService.save(user);
            return Util.getMessage(UtilMessages.USER_CREATION_SUCCESS,true);
            
            

        }
       
    }
	
}

