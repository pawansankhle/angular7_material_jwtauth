package yash.first.demo.demo.util;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class Util {
	
	public static ResponseEntity getMessage(String msg,Boolean isSuccess) {
		JSONObject result = new JSONObject(); 
		
		try {
			if(isSuccess) {
				result.put("status", "sucess");
			}else {
				result.put("status", "failed");
			}
			
			result.put("msg", msg);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity(result.toString(),HttpStatus.OK);
		
	}

}
