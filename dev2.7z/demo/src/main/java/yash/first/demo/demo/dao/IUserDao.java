package yash.first.demo.demo.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import yash.first.demo.demo.model.User;

@Repository
public interface IUserDao extends JpaRepository<User, Long> {

	User findByUsername(String username);
	User findByEmail(String email);

	

	
	
}
