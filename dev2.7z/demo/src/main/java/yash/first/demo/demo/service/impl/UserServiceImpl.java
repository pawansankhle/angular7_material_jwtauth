package yash.first.demo.demo.service.impl;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import yash.first.demo.demo.dao.IRoleDao;
import yash.first.demo.demo.dao.IUserDao;
import yash.first.demo.demo.model.Role;
import yash.first.demo.demo.model.User;
import yash.first.demo.demo.service.IUserService;
import yash.first.demo.demo.util.Util;
import yash.first.demo.demo.util.UtilMessages;

@Service(value = "userService")
public class UserServiceImpl implements IUserService,UserDetailsService{

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IUserDao dao;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private IRoleDao roleDao;
	
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException,LockedException {
		LOGGER.info("in load user by name:: " + username);
		User user = dao.findByUsername(username);
		if(user == null) {
			LOGGER.error("Invalid username or password.");
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		
		return user;
	}
	
	
	@Override
	public List<User> findAll() {
		return dao.findAll();
	}
	
	@Override
	public User findOne(String username) {
		return dao.findByUsername(username);
	}
	
	@Override
	public User findById(Long id) {
		return dao.findById(id).get();
	}
	
	
	
	@Override
	public ResponseEntity save(User user) {
		try {
			User oldUser = dao.findByUsername(user.getUsername());
			
			if(user.getUsername() != null && oldUser == null) {
				LOGGER.info("user "+user.toString());
				user.setEnabled(true);
				user.setAccountNonExpired(true);
				user.setCredentialsNonExpired(true);
				user.setLocked(false);
			
				Role userRole = roleDao.findByRole("ADMIN");
				Set<Role> roles = new HashSet<Role>();
				roles.add(userRole);
				user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
				user.setRoles(roles);
				dao.save(user);
			}else {
				return Util.getMessage(UtilMessages.USER_EXIST,false);
			}
			 
		}catch(Exception ex) {
		LOGGER.error("Exception while creating user::"+ex.getLocalizedMessage());
		ex.printStackTrace();
		
		return Util.getMessage("failed",false);
		}
		return Util.getMessage("success",false);
	}

	

	

	@Override
	public User findByEmail(String email) {
		return dao.findByEmail(email);
	}
	
	
	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		
	}

	

	

	




	
}
