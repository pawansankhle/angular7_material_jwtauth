package yash.first.demo.demo.util;

public class UtilMessages {
	
	public static final String USER_EXIST = "There is already a user registered with the email provided";
	public static final String USER_CREATION_ERROR  = "Some Error while creating User";
	public static final String USER_CREATION_SUCCESS = "User Created Successfully !!";
	public static final String SOMETHING_WENT_WRONG = "Something Went Wrong !!";
}
