insert into user(user_id,active,username,password,email) values(1,1,'admin','$2a$10$bXFcTL0NjuBbd7RfTH6BX.vbwM6l7U/7tKb.1x.4sdJR7L1HopENO','admin@gmail.com'); /* password is admin*/

insert into role(role_id,role) values (1,'ADMIN');

insert into user_role(user_id,role_id)  values (1,1);