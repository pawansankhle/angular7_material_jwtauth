import { Component, OnInit, Input } from '@angular/core';
import { User } from '../../../shared/models/user.model';
import { MediaChange, ObservableMedia } from '@angular/flex-layout';
import { AuthService } from '../../../auth/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private media: ObservableMedia,public auth: AuthService) { }

  ngOnInit() {
    this.auth.getUserProfile()
      .subscribe(user => {
          this.user = user;
      });

      this.media.subscribe((mediaChange: MediaChange) => {
        this.toggleView();
    });
  }

  user:User;
  sideNavOpened: boolean = true;
  matDrawerOpened: boolean = false;
  matDrawerShow: boolean = true;
  sideNavMode: string = 'side';

  @Input() isVisible : boolean = true;
  visibility = 'shown';
  
  ngOnChanges() {
   this.visibility = this.isVisible ? 'shown' : 'hidden';
  }

	
    
  
    getRouteAnimation(outlet) {

       return outlet.activatedRouteData.animation;
       //return outlet.isActivated ? outlet.activatedRoute : ''
    }

  toggleView() {
		if (this.media.isActive('gt-md')) {
            this.sideNavMode = 'side';
            this.sideNavOpened = true;
            this.matDrawerOpened = false;
            this.matDrawerShow = true;
        } else if(this.media.isActive('gt-xs')) {
            this.sideNavMode = 'side';
            this.sideNavOpened = false;
            this.matDrawerOpened = true;
            this.matDrawerShow = true;
        } else if (this.media.isActive('lt-sm')) {
            this.sideNavMode = 'over';
            this.sideNavOpened = false;
            this.matDrawerOpened = false;
            this.matDrawerShow = false;
        }
	}

}
