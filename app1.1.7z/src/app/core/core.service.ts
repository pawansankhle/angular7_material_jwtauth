import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable,pipe } from 'rxjs';
import { map , catchError} from 'rxjs/operators';


@Injectable()
export class CoreService {

    constructor(public http: HttpClient,public router : Router){}
    
    post(url:string,data:any) {
        return this.http.post(url,data)
        .pipe(map(res => { return this.extractData(res)}),
        catchError(res => {return this.handleErrorObservable(res)}));
        
    }

    get(url:string) {
        return this.http.get(url)
        .pipe(
            map(res => { return this.extractData(res)}),
            catchError(res => {return this.handleErrorObservable(res)})
        )
    }

    private handleErrorObservable (res: Response | any) {
      if(res.error!=undefined && res.error !=null && res.error.status == 401) {
           this.router.navigate(['auth/login'],{ queryParams:  {error : res.error.message} , skipLocationChange: true});
        }
        return Observable.throw(res.error || res);
    }

    private extractData(res: Response | any) {
        let body = res;
        return body || {};
    }
   
    
}