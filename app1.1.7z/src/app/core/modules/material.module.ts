import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule} from '@angular/flex-layout';
import {
   MatButtonModule,
   MatCheckboxModule, 
   MatToolbarModule, 
   MatMenuModule,
   MatIconModule,
   MatInputModule,
   MatFormFieldModule,
   MatCardModule,
   MatGridListModule,
   MatSidenavModule,
   MatChipsModule,
   MatListModule,
   MatTabsModule,
   MatProgressBarModule
   
  } from '@angular/material';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatButtonModule, 
    MatCheckboxModule,
    MatToolbarModule,
    MatMenuModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatCardModule,
    MatGridListModule,
    FormsModule,
    FlexLayoutModule,
    MatSidenavModule,
    MatChipsModule,
    MatListModule,
    MatTabsModule,
    MatProgressBarModule
  ],
  exports: [
    MatButtonModule, 
    MatCheckboxModule,
    MatToolbarModule,
    MatMenuModule,
    MatInputModule,
    MatIconModule,
    MatFormFieldModule,
    MatCardModule,
    MatGridListModule,
    FormsModule,
    FlexLayoutModule,
    MatSidenavModule,
    MatChipsModule,
    MatListModule,
    MatTabsModule,
    MatProgressBarModule

  ]
})
export class MaterialModule { }
