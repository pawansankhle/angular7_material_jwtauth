import { environment as env }  from '../../../../environments/environment';

export const UserConstant = {
    'userLogin': `${env.apiUrl}/login`,
    'userProfile': `${env.apiUrl}/profile`
  };