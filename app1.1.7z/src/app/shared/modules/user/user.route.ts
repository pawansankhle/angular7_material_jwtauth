
import { Routes } from '@angular/router';


export const loginRoutes: Routes = [
   
    { path: 'login',   },
    
    { path: '',
      redirectTo: '/login',
      pathMatch: 'full'
    }
  ];
