import { Component, OnInit } from '@angular/core';
import { User } from '../../../shared/models/user.model';
import { AuthService } from '../../../auth/auth.service';
import { TokenStorageService } from '../../../auth/token.storage.service';
import { Router,ActivatedRoute } from '@angular/router';

@Component({
    selector: 'login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    
    constructor(public auth : AuthService, public token: TokenStorageService, public router : Router,public route:ActivatedRoute) {}
    user : User = new User();
    error: string;

    ngOnInit(): void {
        this.route.queryParams.subscribe(params => {
           this.error = params['error'];
          })
    }

    login(user: User) {
        this.auth.attemptAuth(this.user.username, this.user.password)
        .subscribe(
            data => {
              this.token.saveToken(data.token);
              this.router.navigate(['admin/dashboard']);
            }
          );
    }
    
}
