import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { AuthConstant } from './auth.constant';
import { HttpClient  } from '@angular/common/http';

import {Observable} from 'rxjs';

import { TokenStorageService } from './token.storage.service';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import 'rxjs/add/observable/throw';
import { CoreService } from '../core/core.service';

@Injectable()
export class AuthService {

    constructor(public jwtHelper: JwtHelperService, public http: HttpClient,public tokenService: TokenStorageService, public router : Router,private core: CoreService){}

    public isAuthenticated() {
        const token = this.tokenService.getToken();
        return !this.jwtHelper.isTokenExpired(token);
    }

    public attemptAuth(ussername: string, password: string): Observable<any> {
        const credentials = {username: ussername, password: password};
        return this.core.post(AuthConstant.generateTokenUrl, credentials);
    }

    public logout() {
      this.tokenService.signOut();
       this.router.navigate(['auth/login']);  
        
    }

    public getUserProfile(): any {
        return this.http.get<any>(AuthConstant.userProfile)
        .pipe(map(user => {
            return user
        }));
        
    }
}