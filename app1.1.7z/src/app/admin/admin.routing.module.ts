import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './components/dashboard/dashboard.component';
import { HomeComponent } from '../core/components/home/home.component';


  const appRoutes: Routes = [
    { path: '', component: HomeComponent, children: [
		{ path: 'dashboard', component: AdminDashboardComponent } 
    ]}
];

@NgModule({
  imports: [
    RouterModule.forChild(appRoutes),
  ],
  exports: [
    RouterModule,
  ],
})

export class AuthRoutingModule { }
