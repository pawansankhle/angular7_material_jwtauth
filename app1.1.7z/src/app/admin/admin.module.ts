import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminDashboardComponent } from './components/dashboard/dashboard.component';
import { AuthRoutingModule } from './admin.routing.module';
import { LayoutModule } from '../core/modules/layout.module';

@NgModule({
    declarations: [
        AdminDashboardComponent
    ],
    imports: [ 
        CommonModule,
        AuthRoutingModule,
        LayoutModule
        ],
    exports: [],
    providers: [],
})
export class AdminModule {}